export class Ingridient{
    constructor(public name:string,public amount:number){
        
    }
}