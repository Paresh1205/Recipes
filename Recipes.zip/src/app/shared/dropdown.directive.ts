import { HostBinding } from "@angular/core";
import { Directive, HostListener, Output } from "@angular/core";

@Directive({
selector:'[appDropdown]',
exportAs:'appDropdown'  
})
export class dropdownDirective{
   @HostBinding('class.show') isOpen=false;
   @HostListener('click') toggleOpen(){
    this.isOpen=!this.isOpen;

   }

}