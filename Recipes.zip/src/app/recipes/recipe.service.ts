
import { EventEmitter, Injectable } from "@angular/core";
import { Ingridient } from "../shared/ingridient.model";
import { ShoppingService } from "../shopping-list/shopping.service";
import { Recipe } from "./recipe.model";

@Injectable()
export class RecipeService{
    recipeSelected= new EventEmitter();
    recipeAdd:Ingridient[]=[];

    constructor(private slService: ShoppingService){}

    private recipes:Recipe[]=[
        new Recipe('A Test',
            'this is test recipe',
            'https://images.immediate.co.uk/production/volatile/sites/30/2020/08/chorizo-mozarella-gnocchi-bake-cropped-9ab73a3.jpg?quality=90&resize=960,872',
            [
                new Ingridient('meat',1),
                new Ingridient('Fries',20)
            ]  
        )
        ,new Recipe('A Test 2',
            'this is test recipe',
            'https://images.immediate.co.uk/production/volatile/sites/30/2020/08/chorizo-mozarella-gnocchi-bake-cropped-9ab73a3.jpg?quality=90&resize=960,872'
            ,[
                new Ingridient('meat',1),
                new Ingridient('buns',2)
            ]
        )
        
    ];

    getRecipes(){
        return this.recipes.slice();
    }
    getRecipe(id:number){
        return this.recipes[id]
    }
    addToShoppingList(ingridients:Ingridient[]){
        this.slService.addIngridientsFromRecipe(ingridients);
    }
    
}