import { EventEmitter } from '@angular/core';
import { Ingridient } from '../shared/ingridient.model';

export class ShoppingService{
    ingridientsChanged = new EventEmitter<Ingridient[]>();
    private ingridients:Ingridient[]=[
        new Ingridient('apple',5),
        new Ingridient('tomatoes',10)
    ];

    getIngridients(){
       return this.ingridients.slice();
    }

    addIngridients(ingridient: Ingridient){
        this.ingridients.push(ingridient);
        this.ingridientsChanged.emit(this.ingridients.slice());
    }

    addIngridientsFromRecipe(ingridients:Ingridient[]){
        this.ingridients.push(...ingridients);
        this.ingridientsChanged.emit(this.ingridients.slice());
    }
}